package com.example.zadanie3auth;

public class Auth {
        public String Username;
        public boolean isAdmin;
        private String Password;

    public Auth(String user, String passwd, Boolean admin){
        Username = user;
        Password = "abc"+passwd+"def";
        isAdmin = admin;
    }

    public boolean checkPass(String user, String pass){
        String passSalt = "abc"+pass+"def";
        if(user.equals(Username) && passSalt.equals(Password)) return true;
        else return false;
    }
}

